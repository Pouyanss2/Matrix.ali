import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const MatrixApp());

class MatrixApp extends StatelessWidget {
  const MatrixApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('My App'),
        backgroundColor: Colors.black,
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const MatrixPage()),
            );
          },
          child: const Text('گزینه ۱ - MATRIX'),
        ),
      ),
    );
  }
}

class MatrixPage extends StatefulWidget {
  const MatrixPage({super.key});

  @override
  State<MatrixPage> createState() => _MatrixPageState();
}

class _MatrixPageState extends State<MatrixPage> {
  DateTime? lastBack;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void handleBack() {
    final now = DateTime.now();

    if (lastBack == null ||
        now.difference(lastBack!) > const Duration(seconds: 2)) {
      lastBack = now;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('برای خروج دوباره دکمه برگشت را بزنید'),
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) handleBack();
      },
      child: const Scaffold(
        backgroundColor: Colors.black,
        body: SizedBox.expand(child: MatrixRain()),
      ),
    );
  }
}

class MatrixRain extends StatefulWidget {
  const MatrixRain({super.key});

  @override
  State<MatrixRain> createState() => _MatrixRainState();
}

class _MatrixRainState extends State<MatrixRain> {
  final Random random = Random();
  final List<String> characters =
      '01ABCDEFGHIJKLMNOPQRSTUVWXYZアイウエオカキクケコ'.split('');

  late final Timer timer;
  final List<MatrixColumn> columns = [];

  @override
  void initState() {
    super.initState();

    for (int i = 0; i < 80; i++) {
      columns.add(
        MatrixColumn(
          x: random.nextDouble(),
          y: random.nextDouble(),
          speed: 0.003 + random.nextDouble() * 0.008,
          length: 8 + random.nextInt(18),
        ),
      );
    }

    timer = Timer.periodic(const Duration(milliseconds: 40), (_) {
      if (!mounted) return;
      setState(() {
        for (final column in columns) {
          column.y += column.speed;
          if (column.y > 1.2) {
            column.y = -0.2;
            column.x = random.nextDouble();
          }
        }
      });
    });
  }

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: MatrixPainter(
        columns: columns,
        characters: characters,
        random: random,
      ),
      size: Size.infinite,
    );
  }
}

class MatrixColumn {
  double x, y, speed;
  int length;

  MatrixColumn({
    required this.x,
    required this.y,
    required this.speed,
    required this.length,
  });
}

class MatrixPainter extends CustomPainter {
  final List<MatrixColumn> columns;
  final List<String> characters;
  final Random random;

  MatrixPainter({
    required this.columns,
    required this.characters,
    required this.random,
  });

  @override
  void paint(Canvas canvas, Size size) {
    const fontSize = 15.0;
    final textPainter = TextPainter(textDirection: TextDirection.ltr);

    for (final column in columns) {
      final x = column.x * size.width;
      final startY = column.y * size.height;

      for (int i = 0; i < column.length; i++) {
        final y = startY - i * fontSize;
        if (y < 0 || y > size.height) continue;

        final char = characters[random.nextInt(characters.length)];
        final opacity = 1.0 - (i / column.length);

        textPainter.text = TextSpan(
          text: char,
          style: TextStyle(
            color: Colors.green.withOpacity(opacity),
            fontSize: fontSize,
            fontWeight: FontWeight.bold,
          ),
        );

        textPainter.layout();
        textPainter.paint(canvas, Offset(x, y));
      }
    }
  }

  @override
  bool shouldRepaint(covariant MatrixPainter oldDelegate) => true;
}
