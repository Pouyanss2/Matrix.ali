# Matrix App

This is a Flutter project prepared for Android APK building.

The Android platform files are generated automatically in CI with:
`flutter create --platforms=android .`

Then the release APK is built with:
`flutter build apk --release`
